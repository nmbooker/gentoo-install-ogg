/* -*-c-*- */

#ifndef FVWM_CMDPARSER_OLD_H
#define FVWM_CMDPARSER_OLD_H

/* ---------------------------- interface functions ------------------------ */

/* return the hooks structure of the old parser */
const cmdparser_hooks_t *cmdparser_old_get_hooks(void);

#endif /* FVWM_CMDPARSER_OLD_H */
