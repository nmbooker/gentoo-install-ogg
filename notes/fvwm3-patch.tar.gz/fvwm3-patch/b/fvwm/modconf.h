/* -*-c-*- */

#ifndef FVWM_MODCONF_H
#define FVWM_MODCONF_H


void ModuleConfig(char *action);

#endif /* FVWM_MODCONF_H */
