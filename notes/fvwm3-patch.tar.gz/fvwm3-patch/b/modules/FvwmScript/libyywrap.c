/* libyywrap - flex run-time support library "yywrap" function */

int yywrap(void)
{
	return 1;
}
