/* -*-c-*- */

#ifndef FVWMBUTTONS_DYNAMIC_H
#define FVWMBUTTONS_DYNAMIC_H

/* ---------------------------- included header files ----------------------- */

/* ---------------------------- global definitions -------------------------- */

/* ---------------------------- global macros ------------------------------- */

/* ---------------------------- type definitions ---------------------------- */

/* ---------------------------- forward declarations ------------------------ */

/* ---------------------------- exported variables (globals) ---------------- */

/* ---------------------------- interface functions ------------------------- */

void parse_message_line(char *line);

#endif /* FVWMBUTTONS_DYNAMIC_H */
