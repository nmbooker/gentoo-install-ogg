#ifndef FVWMLIB_CURSOR_H
#define FVWMLIB_CURSOR_H

int fvwmCursorNameToIndex (char *cursor_name);

#endif /* FVWMLIB_CURSOR_H */
