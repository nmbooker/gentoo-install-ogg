/* -*-c-*- */

#ifndef FVWMLIB_SETPGRP_H
#define FVWMLIB_SETPGRP_H

int fvwm_setpgrp(void);

#endif
