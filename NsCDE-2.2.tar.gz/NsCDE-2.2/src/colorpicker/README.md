# colorpicker
A small tool for X11 that writes the color value on your screen at the cursor position to stdout, in RGB.

### Usage
Left click to print the pixel color, any other mouse click to quit the program.

### Dependencies
XLib

### License
MIT
