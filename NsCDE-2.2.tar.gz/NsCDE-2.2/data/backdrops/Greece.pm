/* XPM */
/* This file is a part of the NsCDE - Not so Common Desktop Environment */
static char * Greece_pm[] = {
"20 20 4 1",
/* colors */
"o   s selectColor   m black   c #737373737373",
".   s background   m white   c #949494949494",
"X   s bottomShadowColor   m black   c #636363636363",
"    s selectColor   m black   c #737373737373",
/* pixels */
" ..................X",
" .o   oo   oo   oo X",
"o. ooo  ooo  ooo  oX",
"o. oXXXXXXXXXXXXX oX",
" .o X oo   oo   .o X",
" .o X ........X .o X",
" .o X .o   oo X .o X",
"o. oXo. ooo  oXo. oX",
"o. oXo. oXXXXXXo. oX",
" .o X .o X oo   .o X",
" .o X .o X ......o X",
" .o X .o X .o   oo X",
"o. oXo. oXo. ooo  oX",
"o. oXo. oXoXXXXXXXXX",
" .o X .o X oo   oo  ",
"..o X .o X..........",
" oo X .o   oo   oo  ",
"o  oXo. ooo  ooo  oo",
"XXXXXoXXXXXXXXXXXXXX",
" oo   oo   oo   oo  "};
