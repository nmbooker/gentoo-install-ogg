/* XPM */
/* This file is a part of the NsCDE - Not so Common Desktop Environment */
static char *Squares_pm[] = {
/* width height ncolors chars_per_pixel */
"32 32 3 1",
/* colors */
"  s selectColor   m black   c #737373737373",
". s background    m black   c #949494949494",
"X s bottomShadowColor   m black c #636363636363",
/* pixels */
"                                ",
"                                ",
"                                ",
"                                ",
"    XXXXXXXXXXXXXXXXXXXXXXX.    ",
"    X                      .    ",
"    X                      .    ",
"    X                      .    ",
"    X                      .    ",
"    X                      .    ",
"    X                      .    ",
"    X                      .    ",
"    X                      .    ",
"    X                      .    ",
"    X                      .    ",
"    X                      .    ",
"    X                      .    ",
"    X                      .    ",
"    X                      .    ",
"    X                      .    ",
"    X                      .    ",
"    X                      .    ",
"    X                      .    ",
"    X                      .    ",
"    X                      .    ",
"    X                      .    ",
"    X                      .    ",
"    ........................    ",
"                                ",
"                                ",
"                                ",
"                                "
};
