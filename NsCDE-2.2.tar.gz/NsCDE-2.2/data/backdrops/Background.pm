/* XPM */
static char *Background[] = {
/* columns rows colors chars-per-pixel */
"16 16 2 1",
"   s bottomShadowColor m black c #636363636363",
".  s black m black c black",
/* pixels */
"                ",
"                ",
"                ",
"                ",
"                ",
"                ",
"                ",
"                ",
"                ",
"                ",
"                ",
"                ",
"                ",
"                ",
"                ",
"                "
};
