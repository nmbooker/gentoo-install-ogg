/* XPM */
static char *writer.t[] = {
/* columns rows colors chars-per-pixel */
"16 16 6 1",
"  c navy",
". c blue",
"X c #808080",
"o c #C0C0C0",
"O c gray100",
"+ c None",
/* pixels */
"........    ...X",
".......XOOOo ...",
"o.o.OOOO    X.o.",
".o.       Oo X.o",
"o.X.X. OOOO X.o.",
".  OOOOO   X.o.o",
" OOo  O XoO.o.oX",
".   .o ooOO....+",
"o.o.o.o.o.o.o.o+",
"....OOOOO.....X+",
"....OOOOO.....++",
"..............++",
"X.X.OOOOOOO.X.++",
"....OOOOOOO...++",
"X.X.X.X.X.X.X.X+",
". . . . . . . .+"
};
