/* XPM */
/* $XConsortium: DtABmbr.pm /main/3 1995/07/18 16:14:17 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/
static char * menubar_s_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"28 20 5 1 0 0",
/* colors */
"     s iconGray4     m white c #949494949494",
".    s iconGray1     m white c #dededededede",
"X	s iconColor1	m black	c black",
"o    s iconGray5     m black c #737373737373",
"O	s iconColor2	m white	c white",
/* pixels */
"                            ",
"                            ",
"                            ",
"                            ",
"                            ",
"                            ",
"                            ",
"...........................X",
".ooooooooooooooooooooooooooX",
".oOOoOooooOOoOoOoooooooooooX",
".oOoOOOoooOoOOOOoooooooooooX",
"XXXXXXXXXXXXXXXXXXXXXXXXXXXX",
"                            ",
"                            ",
"                            ",
"                            ",
"                            ",
"                            ",
"                            ",
"                            "};
