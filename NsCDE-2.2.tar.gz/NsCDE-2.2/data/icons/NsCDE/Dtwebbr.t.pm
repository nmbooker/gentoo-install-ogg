/* XPM */
/****************************************************************
*  Copyright (c) 1996 Sun Microsystems, Inc.
*  All Rights Reserved
*****************************************************************/
static char * SDtwebbr_t_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"16 16 14 1 0 0",
/* colors */
" 	s none	m none	c none",
".	s iconGray7	m black	c #424242424242",
"X	s iconColor2	m white	c white",
"o	s iconGray4	m white	c #949494949494",
"O	s iconGray2	m white	c #bdbdbdbdbdbd",
"+	s iconColor7	m white	c cyan",
"@	s iconGray8	m black	c #212121212121",
"#	s iconColor4	m white	c green",
"$	s iconGray6	m black	c #636363636363",
"%	s iconColor1	m black	c black",
"&	s iconColor5	m black	c blue",
"*	s iconGray5	m black	c #737373737373",
"=	s iconGray3	m white	c #adadadadadad",
"-	s iconGray1	m white	c #dededededede",
/* pixels */
"      .....XX   ",
"    ..oXOo+..X@ ",
"  XX.XX#Ooo$.X@ ",
" X@.O+OOXXXXX@  ",
" OXXXXXXo@@@@%  ",
"   @@@@$$o#$&%  ",
"   .ooo$$$o$$%  ",
"  XXXXXX*$$.&@X ",
"  X@@@@=@...%.X@",
"  X@***X@&.%% X@",
"  X@***X@%%.XX@ ",
"  X=XXXX@  X@@  ",
"  *@@@@@@ X@    ",
" X*X*X*X*X@     ",
"-----------     ",
"@@@@@@@@@@@@    "};
