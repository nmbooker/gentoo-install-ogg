/* XPM */
static char *math.t[] = {
/* columns rows colors chars-per-pixel */
"16 16 6 1",
"  c #008080",
". c cyan",
"X c #808080",
"o c #C0C0C0",
"O c gray100",
"+ c None",
/* pixels */
". . . . XXXX. .o",
" . . o XOOOoX. .",
"...oOOOO    ....",
"o.o       Ooo.o.",
"...ooo OOOO ....",
"oXXOOOOO  X.o.o.",
"XOOo  O .......o",
"X   X. OOOOOX.X+",
".o.o.OOOOOOO.o.+",
"X.X.X.OOX.X.X.o+",
".o.o.o.OOo.o.o++",
" . . . OO. . .++",
". . . OO. . . ++",
" . . OOOOOOO .++",
". . .OOOOOOO. o+",
" . . . . . . . +"
};
