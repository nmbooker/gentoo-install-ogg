/* XPM */
/* $XConsortium: Dtinf.t.pm /main/3 1995/07/18 16:41:48 drk $ */
static char * Dtinf_t_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"16 16 5 1 0 0",
/* colors */
" 	s iconColor2	m white	c white",
".	s none	m none	c none",
"X    s iconGray2     m white c #bdbdbdbdbdbd",
"o	s iconColor1	m black	c black",
"O    s iconGray5     m black c #737373737373",
/* pixels */
"              ..",
" XXXXXXXXXXXXo..",
" XXXXOOOOXXXXo..",
" XXXOXXXXOXXXo..",
" XXXOXXXXOXXXo..",
" XXXXOXXOXXXXo..",
" XXXXOXXOXXXXo..",
" XXXXXOOXXXXXo..",
" XXXXXOOXXXXXo..",
" XXXXOXXOXXXXo..",
" XXXXOXXOXXXXo..",
" XXXOXXXXOXXXo..",
" XXXOXXXXOXXXo..",
" XXXXOOOOXXXXo..",
" XXXXXXXXXXXXo..",
" ooooooooooooo.."};
