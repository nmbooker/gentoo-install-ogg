/* XPM */
/*********************************************************************
*  (c) Copyright 1997 Sun Microsystems, Inc.
*  All Rights Reserved
**********************************************************************/
static char * error_log_t_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"16 16 8 1 0 0",
/* colors */
" 	s iconColor2	m white	c white",
".	s none	m none	c none",
"X	s iconGray2	m white	c #bdbdbdbdbdbd",
"o	s iconGray8	m black	c #212121212121",
"O	s iconGray7	m black	c #424242424242",
"+	s iconGray1	m white	c #dededededede",
"@	s iconColor3	m black	c red",
"#	s iconGray4	m white	c #949494949494",
/* pixels */
"             ...",
" XXXXXXXXXXXo...",
" XOOXOOXXXXXo...",
" XXXXXXX+++++++.",
" XOOXOX+@@@@@@@o",
" XXXXXX+@@@ #@@o",
" XOOOXX+@@@ #@@o",
" XXXXXX+@@@ #@@o",
" XOOXOX+@@@ #@@o",
" XXXXXX+@@@@@@@o",
" XOXOOX+@@@ #@@o",
" XXXXXX+@@@@@@@o",
" XOOXOXXooooooo.",
" XXXXXXXXXXXo...",
" XXXXXXXXXXXo...",
" oooooooooooo..."};
