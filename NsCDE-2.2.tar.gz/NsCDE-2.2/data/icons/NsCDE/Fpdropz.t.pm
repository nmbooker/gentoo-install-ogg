/* XPM */
/* $XConsortium: Fpdropz.t.pm /main/3 1995/07/18 16:56:34 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/

static char * Fdropzn [] = {
/* width height ncolors cpp [x_hot y_hot] */
"16 16 5 1 0 0",
/* colors */
" 	s none	m none	c none",
".    s bottomShadowColor m black c #636363636363",
"X    s selectColor m white c #737373737373",
"o    s background    m black c #949494949494",
"O    s topShadowColor m white c #bdbdbdbdbdbd",
/* pixels */
"                ",
"                ",
"                ",
"................",
".XoXoXoXoXoXoXoO",
".o............XO",
".X.XoXoXoXoXoOoO",
".o.oXoXoXoXoXOXO",
".X.XoXoXoXoXoOoO",
".o.oXoXoXoXoXOXO",
".X.XoXoXoXoXoOoO",
".o.OOOOOOOOOOOXO",
".XoXoXoXoXoXoXoO",
".OOOOOOOOOOOOOOO",
"                ",
"                "};
