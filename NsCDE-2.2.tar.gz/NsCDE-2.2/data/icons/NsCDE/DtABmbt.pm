/* XPM */
/* $XConsortium: DtABmbt.pm /main/3 1995/07/18 16:14:26 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/
static char * menubutton_s_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"28 20 7 1 0 0",
/* colors */
"     s iconGray4     m white c #949494949494",
".    s iconGray1     m white c #dededededede",
"X    s iconGray1     m white c #dededededede",
"o    s iconGray3     m white c #adadadadadad",
"O	s iconColor1	m black	c black",
"+    s iconGray5     m black c #737373737373",
"@    s iconGray2     m white c #bdbdbdbdbdbd",
/* pixels */
"                            ",
"                            ",
"                            ",
"                            ",
".XXXXXXXXXXXXXXXXXXXXXXXXXX.",
".ooooooooooooooooooooooooooO",
".ooooooooooooooooooooooooooO",
".ooooooooooooooooo+.......+O",
".oooooooooooooooooo+O@@@O+oO",
".ooooooooooooooooooo+O@O+ooO",
".oooooooooooooooooooo+O+oooO",
".ooooooooooooooooooooo+ooooO",
".ooooooooooooooooooooooooooO",
".OOOOOOOOOOOOOOOOOOOOOOOOOOO",
"                            ",
"                            ",
"                            ",
"                            ",
"                            ",
"                            "};
