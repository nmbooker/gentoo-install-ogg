/* XPM */
/*********************************************************************
*  (c) Copyright 1996 Sun Microsystems, Inc.
**********************************************************************/
static char * Properties6_t_xpm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"16 16 7 1 0 0",
/* colors */
" 	s none	m none	c none",
".	s iconColor2	m white	c white",
"X	s iconColor5	m black	c blue",
"o	s iconColor1	m black	c black",
"O	s iconGray2	m white	c #bdbdbdbdbdbd",
"+	s iconGray5	m black	c #737373737373",
"@	s iconGray3	m white	c #adadadadadad",
/* pixels */
"         .XXXXo ",
"  .......XXXXXXo",
" .OOOOOOOOOOOO+o",
" .OOOOOOOOOOOO+o",
".........OOOOO+o",
".OOOOOOOoOOOOO+o",
".OOOOOOO......+o",
".OooOoO.XXXXXXoo",
".OOOOO.XXX..XXXo",
".OOOOO.XXXXXXXXo",
".OoOoO.XXX..XXXo",
".OOOOO.XXX..XXXo",
".OOOOO.XXX..XXXo",
".OoOooO.XX@@XXo ",
".OOOOOOooooooo  ",
".ooooooo        "};
