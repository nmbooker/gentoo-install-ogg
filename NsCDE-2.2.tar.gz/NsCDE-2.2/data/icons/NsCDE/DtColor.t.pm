/* XPM */
/*********************************************************************
*  (c) Copyright 1999 Sun Microsystems, Inc.
**********************************************************************/
static char * Color_t_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"16 16 13 1 0 0",
/* colors */
" 	s none	m none	c none",
".	s iconGray6	m black	c #636363636363",
"X	s iconGray1	m white	c #dededededede",
"o	s iconGray3	m white	c #adadadadadad",
"O	s iconColor8	m black	c magenta",
"+	s iconColor6	m white	c yellow",
"@	s iconColor3	m black	c red",
"#	s iconGray5	m black	c #737373737373",
"$	s iconGray8	m black	c #212121212121",
"%	s iconGray2	m white	c #bdbdbdbdbdbd",
"&	s iconColor4	m white	c green",
"*	s iconColor5	m black	c blue",
"=	s iconColor1	m black	c black",
/* pixels */
"                ",
"                ",
"     ......     ",
"   ..XXXXXX..   ",
"  .XXoooOOooo.  ",
" .X+++oOOOooo.  ",
".Xo++@oooo#$.   ",
"$Xo+@oo$$o$  $. ",
"$Xooooo$#oo.$o$%",
" $Xo@@oooo&&oo$%",
" $Xo@@o**o*&o$% ",
"  $#ooo*=oo$$%% ",
"   %$$$$$$$%%%  ",
"     %%%%%%%    ",
"                ",
"                "};
