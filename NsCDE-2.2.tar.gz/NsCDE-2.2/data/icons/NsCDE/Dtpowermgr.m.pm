/* XPM */
/*********************************************************************
*  Copyright (c) 1996 Sun Microsystems, Inc.
*  All Rights Reserved
**********************************************************************/
static char * estar_m_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"32 32 6 1 0 0",
/* colors */
" 	s none	m none	c none",
".	s iconGray2	m white	c #bdbdbdbdbdbd",
"X	s iconGray1	m white	c #dededededede",
"o	s iconColor6	m white	c yellow",
"O	s iconGray4	m white	c #949494949494",
"+	s iconGray8	m black	c #212121212121",
/* pixels */
"            .......             ",
"          .XoooooooX.           ",
"        .ooooooooooooo.         ",
"       ooooooooooooooooo        ",
"      ooooooooooooooooooo       ",
"     ooooooooooooooooooooo      ",
"    ooooooooooooooooooooooo     ",
"   ooooooooooooooooooooooooo    ",
"  .oooooooooooooooo.O++ooooo.   ",
"  oooooooooooo+++++++++oooooo   ",
" .ooooooooooo++++++++++oooooo.  ",
" Xooooooooooo+++++++++++++++oX  ",
".oooooooo.+++++++++++++ooooooo. ",
".ooooooo+++++++++++++++ooooooo. ",
".oooooo++++++++++++++++ooooooo. ",
".ooooo+++++++++++++++++ooooooo. ",
".oooo.++++.oo+++++++++++++++oo. ",
".ooo.++++oooo++++++++++ooooooo. ",
".oo+++++.ooooo+++++++++ooooooo. ",
" Xo+++++ooooooooooo.O++ooooooX  ",
" .o++++oooooooooooooooooooooo.  ",
"  o.++ooooooooooooooooooooooo   ",
"  .ooooooooooooooooooooooooo.   ",
"   ooooooooooooooooooooooooo    ",
"    ooooooooooooooooooooooo     ",
"     ooooooooooooooooooooo      ",
"      ooooooooooooooooooo       ",
"       ooooooooooooooooo        ",
"        .ooooooooooooo.         ",
"          .XoooooooX.           ",
"            .......             ",
"                                "};
