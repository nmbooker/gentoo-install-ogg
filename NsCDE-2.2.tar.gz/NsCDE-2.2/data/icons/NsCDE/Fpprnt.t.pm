/* XPM */
/* $XConsortium: Fpprnt.t.pm /main/3 1995/07/18 17:01:18 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/

static char * Fprnt [] = {
/* width height ncolors cpp [x_hot y_hot] */
"16 16 10 1 0 0",
/* colors */
" 	s none	m none	c none",
".	s iconColor2	m white	c white",
"X    s iconGray2     m white c #bdbdbdbdbdbd",
"o    s iconGray4     m white c #949494949494",
"O    s iconGray1     m white c #dededededede",
"+    s iconGray6     m black c #636363636363",
"@    s iconGray5     m black c #737373737373",
"#    s iconGray8     m black c #212121212121",
"$    s bottomShadowColor m black c #636363636363",
"%    s selectColor m white c #737373737373",
/* pixels */
"                ",
"                ",
"                ",
"                ",
"    ......      ",
"  XX...X..XXXX  ",
" XXoXXXXXXoOXXX ",
" ..............O",
" .OOOOOOOOO+@@X@",
" .XXXXXXXXXXXXX@",
" .X#########XXX@",
" .#.@@@@@@@@###@",
"  ############# ",
"   $$$$$$$$$%   ",
"                ",
"                "};
