/* XPM */
/* $XConsortium: Dtdirup.t.pm /main/3 1995/07/18 16:36:09 drk $ */
static char * Dtdirup_t_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"16 16 11 1 0 0",
/* colors */
" 	s none	m none	c none",
".	s iconColor2	m white	c white",
"X    s iconGray1     m white c #dededededede",
"o	s iconColor5	m black	c blue",
"O    s iconGray8     m black c #212121212121",
"+    s iconGray5     m black c #737373737373",
"@    s iconGray3     m white c #adadadadadad",
"#    s iconGray7     m black c #424242424242",
"$	s iconColor1	m black	c black",
"%    s iconGray2     m white c #bdbdbdbdbdbd",
"&    s iconGray6     m black c #636363636363",
/* pixels */
"      ....X     ",
"     .oooooO    ",
"..........+O    ",
".@@@@@@@@@+O    ",
".@@@@@@@@@+O    ",
".@@@@@@@@@..... ",
".@@@@@@@@@ooooX ",
".@@######.oooooO",
".@@#..........+O",
".OOO.$OOOO$%%%+O",
"    .$$$$#%%%%+O",
"    .$$$&%%%%%+O",
"    .$$&$&%%%%+O",
"    .$$%&$&%%%+O",
"    .&%%%&$&%%+O",
"    .OOOOOOOOOO "};
