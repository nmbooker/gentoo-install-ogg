/* XPM */
/* $XConsortium: DtABbix.m.pm /main/3 1995/07/18 16:11:56 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/

static char * DtABbix_m_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"32 32 12 1 0 0",
/* colors */
"     s topShadowColor m white c #bdbdbdbdbdbd",
".    s iconGray2     m white c #bdbdbdbdbdbd",
"X    s bottomShadowColor m black c #636363636363",
"o    s iconGray4     m white c #949494949494",
"O	s iconColor2	m white	c white",
"+    s iconGray3     m white c #adadadadadad",
"@    s iconGray1     m white c #dededededede",
"#    s iconGray6     m black c #636363636363",
"$	s iconColor4	m white	c green",
"%    s iconGray5     m black c #737373737373",
"&	s iconColor1	m black	c black",
"*	s iconColor5	m black	c blue",
/* pixels */
"                                ",
" ..............................X",
" ..............................X",
" ..............................X",
" .....o.oooo.Oo................X",
" ..OOoOoOO.+oOoO...............X",
" ..O@oOoO.++o@o#...............X",
" ..O@$o+%%%%@oo#...............X",
" ..O@$$$+O%@@@@#...............X",
" ..O@$$$$O%@@@@#...............X",
" ..O@$$$$O%@@@@#...............X",
" ..O@$$+$O%+@@@#...............X",
" ..O@$$+%&&&+@@#+OOOOOOOOOO....X",
" ..O@$$+%%#&$+@#.@@@@@@@@@&....X",
" ..O@$$+%%#&$$+#.@@@@+@@@@&....X",
" ..O@$$+%%#&$$$#.+@@++@@+@&....X",
" ..O@$$$%%#&$$$$.@+@++@+@@&....X",
" ..O@$$$%%#&$$$$$.@@+@@@@@&....X",
" ..O@@++%%#&+++#..@+++@@@@&....X",
" ..O####%%#&####.+++++++OOOOOO.X",
" .......%%#&...+.@@+++@@O****&.X",
" .......%&&&...O@@@@@@@@O****&.X",
" ..............O@@+++++@O****&.X",
" ..............O@@@@@@@@O****&.X",
" ..............O@@@@@@@@O&&&&&.X",
" ..............O@@@@@@@@@@&....X",
" ..............O&&&&&&&&&&&....X",
" ..............................X",
" ..............................X",
" ..............................X",
" ..............................X",
" XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"};
