/* XPM */
/* $XConsortium: Dtpaint.l.pm /main/3 1995/07/18 16:46:06 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/

/* Designed by the User Interaction Design Group, Hewlett-Packard */
static char *paint48[]={
/* width height ncolors cpp [x_hot y_hot] */
"48 48 21 1 0 0",
/* colors */
"  c none m none s none",
"$    s topShadowColor m white c #bdbdbdbdbdbd",
"&    s background    m black c #949494949494",
"(    s selectColor m white c #737373737373",
"*    s bottomShadowColor m black c #636363636363",
". s iconColor1 c black     m black",
"B s iconColor2 c white     m white",
"4 s iconColor3 c red       m black",
"6 s iconColor4 c green     m white",
"8 s iconColor5 c blue      m black",
"0 s iconColor6 c yellow    m black",
"2 s iconColor7 c cyan      m white",
": s iconColor8 c magenta   m white",
"<    s iconGray1     m white c #dededededede",
">    s iconGray2     m white c #bdbdbdbdbdbd",
"@    s iconGray3     m white c #adadadadadad",
"D    s iconGray4     m white c #949494949494",
"F    s iconGray5     m black c #737373737373",
"H    s iconGray6     m black c #636363636363",
"J    s iconGray7     m black c #424242424242",
"L    s iconGray8     m black c #212121212121",
/* pixels */
"                                                ",
"                                                ",
"              >BBBBBBBBBB.                      ",
"             BB..........B.                     ",
"            >>.          .B.                    ",
"            B.             B.                   ",
"            B.             B.                   ",
"            B.             B.                   ",
"            B. B>BBBB>>    B.                   ",
"            B.BB>HJJJH>B>  B.                   ",
"            B..>JHJJJHH>B  >.                   ",
"            B..HHJJJHHHJJB >.                   ",
"           BB..JJJHHHJJJJJB..                   ",
"          BBB..JJJHHHJJJJJBB.                   ",
"         BBHBJ.J888000444666.                   ",
"        BB>HBB.B8888000444666.                  ",
"       BB>B.BH.BB.888000444666.                 ",
"      BB>B>....H.>..8800044466.                 ",
"     BB>B>>>..J>HJ>>.8800044466.                ",
"    BB>B>>>F>J>>.JH>.8800044466.                ",
"    B>B>>>F>J>>JJHJ.J..80044466.                ",
"   B>B>>>F>J>>HJHJHJ.J.80004466.                ",
"   BB>>>F>J>>HJHJHJJJ.J880044666                ",
"   B>>>F>J>>HJHJHJJJJJJ880044466                ",
"   H>>F>J>>HJHJHJJJJJHH880004466.               ",
"   HBF>J>>HJHJHJJJJJHH>880004466.               ",
"    .>J>>FJHJHJJJJJHHD.888004466.               ",
"    D.>>FJHJHJJJJJHHD. 888004446.               ",
"     .>FJHJHJJJJJHHD.  888004446.               ",
"     D..FJHJJJJJHHD.   8880044466.              ",
"      D..FJJJJJHHD.    8880004466.              ",
"       D..FJJJHH..     8880004466.              ",
"         D......       88800044666.             ",
"                      888000044466.             ",
"                     88880000444666             ",
"                    88800000444666666           ",
"               8888880000000444666666666.       ",
"            88888888000000044446666666666.      ",
"            888..88000000B4444.4446.6B6666.     ",
"             8.8B80..0BB0.4.4B4.4.46B6.6B6B...  ",
"            8.8.8B8.0.0BB..4B4B4.44BB...BBB...  ",
"             ...BBB...BBB...BBB...BBB...BBB...  ",
"                ...BBB...BBB...BBB...BBB...     ",
"                ...BBB...BBB...BBB...BBB...     ",
"                ...BBB...BBB...BBB...BBB...     ",
"                         ...                    ",
"                         ...                    ",
"                         ...                    "
};
