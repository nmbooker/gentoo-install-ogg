/* XPM */
/* $XConsortium: Fppenpd.m.pm /main/3 1995/07/18 17:00:54 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/

static char * Fpenpad [] = {
/* width height ncolors cpp [x_hot y_hot] */
"32 32 15 1 0 0",
/* colors */
" 	s none	m none	c none",
".    s bottomShadowColor m black c #636363636363",
"X	s iconColor2	m white	c white",
"o    s topShadowColor m white c #bdbdbdbdbdbd",
"O    s iconGray1     m white c #dededededede",
"+    s iconGray8     m black c #212121212121",
"@	s iconColor1	m black	c black",
"#    s iconGray6     m black c #636363636363",
"$    s iconGray5     m black c #737373737373",
"%    s iconGray7     m black c #424242424242",
"&    s iconGray3     m white c #adadadadadad",
"*    s iconGray2     m white c #bdbdbdbdbdbd",
"=	s iconColor6	m white	c yellow",
"-    s iconGray4     m white c #949494949494",
";    s selectColor m white c #737373737373",
/* pixels */
"                                ",
"  .......................       ",
"  .XXXXXXXXXXXXXXXXXXXXXo       ",
"  .XOOOOOOOOOOOOOOOOOOO+o       ",
"  .XOOOOOOOOOOOOOOOOOOO+o       ",
"  .XOO@@#O@O#@#OOOOOOOO+o       ",
"  .XOOOOOOOOOOOOOOOOOOO+o       ",
"  .XOOOOOOOOOOOOOOOOOOO+o       ",
"  .XOO#@O#O+O@#@O#@OOOO+o       ",
"  .XOOOOOOOOOOOOOOOOOOO+o       ",
"  .XOOOOOOOOOOOOOOOOOOO+o       ",
"  .XOO@#@O@$@$OOOOOOOOO+o       ",
"  .XOOOOOOOO%@$&OOOOOOO+o       ",
"  .XOOOOOOOO%&XX&*OOOOO+o       ",
"  .XOOOOOOOOO%XO=&*OOOO+o       ",
"  .XOOOOOOOOO%#&O=&*OOO+o       ",
"  .XOOOOOOOOOO%#&O=&*OO+o       ",
"  .XOOOOOOOOOO&%#&O=&*O+o       ",
"  .XOOOOOOOOOO&&%#&O=&*+o       ",
"  .XOOOOOOOOOO*&&%#&O=&*o       ",
"  .XOOOOOOOOOOO*&&%#&O=&*       ",
"  .XOOOOOOOOOOOO*&&%#&O=&*      ",
"  .XOOOOOOOOOOOOO*&&%#&O=&*     ",
"  .XOOOOOOOOOOOOOO*&&%#&O=&*    ",
"  .XOOOOOOOOOOOOOOO*&&%#&O=&*   ",
"  .XOOOOOOOOOOOOOOOO*&&%#&O%%*  ",
"  .XOOOOOOOOOOOOOOOOO*&+%%#OO-% ",
"  .XOOOOOOOOOOOOOOOOOO*+ %%-O-% ",
"  .X++++++++++++++++++++ ;%--%%;",
"  .oooooooooooooooooooooo;;%%%;;",
"                          ;;;;; ",
"                           ;;;  "};
