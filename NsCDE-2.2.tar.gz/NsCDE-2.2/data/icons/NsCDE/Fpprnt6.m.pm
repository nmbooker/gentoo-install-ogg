/* XPM */
/* $XConsortium: Fpprnt6.m.pm /main/3 1995/07/18 17:02:59 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/

static char * Fprnt07 [] = {
/* width height ncolors cpp [x_hot y_hot] */
"32 32 13 1 0 0",
/* colors */
" 	s none	m none	c none",
".	s iconColor2	m white	c white",
"X    s iconGray2     m white c #bdbdbdbdbdbd",
"o    s iconGray1     m white c #dededededede",
"O    s bottomShadowColor m black c #636363636363",
"+    s topShadowColor m white c #bdbdbdbdbdbd",
"@    s iconGray3     m white c #adadadadadad",
"#    s iconGray7     m black c #424242424242",
"$    s iconGray5     m black c #737373737373",
"%    s iconGray4     m white c #949494949494",
"&    s iconGray6     m black c #636363636363",
"*    s iconGray8     m black c #212121212121",
"=    s selectColor m white c #737373737373",
/* pixels */
"                                ",
"                                ",
"                                ",
"                                ",
"        ...........             ",
"      ...............           ",
"     ..X.X.X.X.X.X.X..          ",
"    ....X.X.X.X.X.X....         ",
"   .....................        ",
"       ooXoXooXoXoXo            ",
"    OOOooXXXoXoXXoXoOOOOOOO+    ",
"   O.XooXXooXXoXXXXo@@@XXXX#+   ",
"  O.X$Xooooooooooooo%@@@XXXX#+  ",
" O.XX&$$$$$$$$$$$$$$$$@@@XXXX#+ ",
" O.oooooooooooooooooooooooooo#+ ",
" O.Xoooooooooooooooooo&&&&&&X#+ ",
" O.Xoooooooooooooooooo&$$$$&X#+ ",
" O.XX$$$$$$$$$$$$$$$$$&&&&&&X#+ ",
" O.XXXXXXXXXXXXXXXXXXXXXXXXXX#+ ",
" O.XXXXXXXXXXXXXXXXXXXXXXXXXX#+ ",
" O.XX******************XXXXXX#+ ",
" O.XX*o$$$$$$$$$$$$$$$*XXXXXX#+ ",
" O.**o@@@@@@@@@@@@@@@@@******#+ ",
"   @#%$$$$$$$$$$$$$$$$$####*+++ ",
"   @*&&&&&&&&&&&&&&&&&&*****+   ",
"   ++******************O=+++    ",
"     OOOOOOOOOOOOOOOOOOO=       ",
"      ===================       ",
"                                ",
"                                ",
"                                ",
"                                "};
