/* XPM */
/* $XConsortium: DtRdMe.m.pm /main/3 1995/07/18 16:25:45 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/
static char * DtRdMe_m_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"32 32 8 1 0 0",
/* colors */
" 	s iconColor2	m white	c white",
".	s none	m none	c none",
"X    s iconGray2     m white c #bdbdbdbdbdbd",
"o	s iconColor1	m black	c black",
"O    s iconGray7     m black c #424242424242",
"+    s iconGray4     m white c #949494949494",
"@    s iconGray6     m black c #636363636363",
"#    s iconGray5     m black c #737373737373",
/* pixels */
"                         .......",
" XooXXXXXXXXXXXXXXXXXXXXo.......",
" XooXXXXXXXoXXXXXXXXXXXXo.......",
" XoooXXXXXoooXXXXXXXXXXXo.......",
" XoooXXXXooXXoXXXXXXXXXXo.......",
" XoXoXoXooOXoXo+OXoOoXXXo.......",
" XoXoXXXXo++XXXoXXXXXXXXo.......",
" XoXOoOX+ooOOX+ooOXOO+XXo.......",
" XoXXXXXXXXXX+XXXoXXXXXXo.......",
" XoXoOOXoXooOXoXoooXXXXXo.......",
" XoXXXXXXXXXXXX+XXXoXXXXo.......",
" XoXXXXXXXXXXXXX++XXoXXXo.......",
" XoX+oooooXooXOOXoo+OoXXo.......",
" XoXXoXXXXoXXXXXXooooXoXo.......",
" Xooo++ X++oOOXXo++++oXXo.......",
" XXXoX XXXXoXoXoXXX XXooo.......",
" XXXoX++X++ooOoo+  +XXoXo.......",
" XXXoXXXXXXoXXXoXXXXXXoXo.......",
" XXX+o+X++oXoXooOX++++oXo.......",
" XXXXXoooo++++++oXXXXo+Xo.......",
" XXXO@O++@@OOX+oooooo++Xo.......",
" XXXXXXXXXXXXXXXXX+X+X+Xo.......",
" XXXoOOXoXooOXoXooXXXXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXXXXoXOOXooXOOXoo+OXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXXo+OXXoOOOOXoOOoX##XXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" oooooooooooooooooooooooo......."};
