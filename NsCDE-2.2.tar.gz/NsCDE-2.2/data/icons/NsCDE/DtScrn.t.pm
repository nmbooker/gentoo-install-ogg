/* XPM */
/*********************************************************************
*  (c) Copyright 1999 Sun Microsystems, Inc.
**********************************************************************/
static char * Screen_t_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"16 16 9 1 0 0",
/* colors */
" 	s none	m none	c none",
".	s iconGray6	m black	c #636363636363",
"X	s iconColor2	m white	c white",
"o	s iconGray2	m white	c #bdbdbdbdbdbd",
"O	s iconGray1	m white	c #dededededede",
"+	s iconGray7	m black	c #424242424242",
"@	s iconColor5	m black	c blue",
"#	s iconGray4	m white	c #949494949494",
"$	s iconGray3	m white	c #adadadadadad",
/* pixels */
"                ",
"                ",
"................",
".XXXXXXXXXXXXXXo",
".XOOOoOooooooo+o",
".XO++++++++++o+o",
".XO+@@@@@@@@Xo+o",
".Xo+#XX@X@$@Xo+o",
".XO+@X@X@O@@X$+o",
".Xo+#@X@$@#@Xo+o",
".Xo+@@@@@@@@X$+o",
".Xo+XXXXXXXXX$+o",
".Xooooooo$o$$$+o",
".X+++++++++++++o",
".ooooooooooooooo",
"                "};
