/* XPM */
/*********************************************************************
*  Copyright (c) 2000 Sun Microsystems, Inc.
*  All Rights Reserved
**********************************************************************/
static char * wsctrl_t_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"16 16 6 1 0 0",
/* colors */
" 	s none	m none	c none",
".	s iconGray6	m black	c #636363636363",
"X	s iconGray1	m white	c #dededededede",
"o	s iconGray8	m black	c #212121212121",
"O	s iconGray3	m white	c #adadadadadad",
"+	s iconColor5	m black	c blue",
/* pixels */
"                ",
"                ",
"                ",
"................",
"XXXXXXXXXXXXXXXX",
"oooooooooooooooo",
"OOOOOOOOOOOOOOOO",
"X++++++X++++++oO",
"OOOOOOOOOOOOOOOO",
"X++++++X++++++oO",
"OOOOOOOOOOOOOOOO",
"................",
"XXXXXXXXXXXXXXXX",
"oooooooooooooooo",
"                ",
"                "};
