/* XPM */
/* $XConsortium: Fpterm.m.pm /main/4 1995/07/31 11:18:09 lehors $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/

/* Designed by the User Interaction Design Group, Hewlett-Packard */
static char *newterminal32[]={
/* width height ncolors cpp [x_hot y_hot] */
"32 32 21 1 0 0",
/* colors */
"  c none m none s none",
"$ s topShadowColor     m white",
"& s background         m black",
"( s selectColor        m white",
"* s bottomShadowColor  m black",
". s iconColor1 c black     m black",
", s iconColor2 c white     m white",
"4 s iconColor3 c red       m black",
"6 s iconColor4 c green     m white",
"8 s iconColor5 c blue      m black",
"0 s iconColor6 c yellow    m black",
"2 s iconColor7 c cyan      m white",
": s iconColor8 c magenta   m white",
"< s iconGray1 m white c #dededededede",   
"> s iconGray2 m white c #bdbdbdbdbdbd",   
"@ s iconGray3 m white c #adadadadadad",   
"D s iconGray4 m white c #949494949494",   
"F s iconGray5 m black c #737373737373",   
"H s iconGray6 m black c #636363636363",   
"J s iconGray7 m black c #424242424242",   
"L s iconGray8 m black c #212121212121",   
/* pixels */
"                                ",
"                                ",
"       *****************$       ",
"      *<<<<<<<<<<<<<<<<>*$      ",
"     *,,,,,,,,,,,,,,,,,,,.$     ",
"    *,>>>>>>>>>>>>>>>>>>>>.$    ",
"    *,>HHHHHHHHHHHHHHHHHH>.$    ",
"    *,>H................,>.$    ",
"    *,>H.JJJJJJJJJJJJJJ.,>.$    ",
"    *,>H.J<J<J<J<JJJJJJ.,>.$    ",
"    *,>H.JJJJJJJJJJJJJJ.,>.$    ",
"    *,>H.JD<J<JD<J<JJJJ.,>.$    ",
"    *,>H.JJJJJJJJJJJJJJ.,>.$    ",
"    *,>H.J<D<J<J<DJJJJJ.,>.$    ",
"    *,>H.JJJJJJJJJJJJJJ.,>.$    ",
"    *,>H.JJJJJJJJJJJJJJ.,>.$    ",
"    *,>H.JJJJJJJJJJJJJJ.,>.$    ",
"    *,>H................,>.$    ",
"    *,>H,,,,,,,,,,,,,,,,,>.$    ",
"    *D>>>>>>>>>>>>>>>>>>>>.$    ",
"     $....................$     ",
"      $$$..HHHHHHHHHH..$$$      ",
"    *****...FFFFFFFF...$*****   ",
"   *FFFFFFFFFFFFFFFFFFFFFFFF.$  ",
"  *,,,F,F,F,F,F,F,F,F,,F,F,H,.$ ",
" *,,,H,H,H,H,H,H,H,H,H,,H,H,,,.$",
"*,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,.",
"*DDDDDDDDDDDDDDDDDDDDDDDDDDDDDD.",
"*...............................",
" $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$",
"                                ",
"                                "
};
