/* XPM */
/* $XConsortium: DtBeep.pm /main/3 1995/07/18 16:16:44 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/

static char * Beep [] = {
/* width height ncolors cpp [x_hot y_hot] */
"39 37 11 1 0 0",
/* colors */
" 	s none	m none	c none",
".    s bottomShadowColor m black c #636363636363",
"X	s iconColor2	m white	c white",
"o    s iconGray1     m white c #dededededede",
"O    s iconGray3     m white c #adadadadadad",
"+    s iconGray2     m white c #bdbdbdbdbdbd",
"@    s iconGray7     m black c #424242424242",
"#    s iconGray5     m black c #737373737373",
"$    s iconGray8     m black c #212121212121",
"%    s topShadowColor m white c #bdbdbdbdbdbd",
"&    s iconGray4     m white c #949494949494",
/* pixels */
"                                       ",
"                                       ",
"                                       ",
"                                       ",
"                  ....                 ",
"       X          .ooo.                ",
"                  .oOO+.               ",
"       @ X        .O@@O+.              ",
"                  .X@#OO+.             ",
"         @ X      .X@@OOO+.            ",
"                  .X@@XOOO+.           ",
"           @ X    .X@#XXOOO+.          ",
"    X X           .X@@XXXOOO........   ",
"        X    @ X  .O@#XXXXOOO++++++..  ",
"    @ @   X X     .OO#+X+XXO@OOOOOO$%  ",
"        @      @  .O@@X+X+XXOXXXXXX&%  ",
"          @ @     .O@@OXOXOX@X+X+X+$%  ",
"                 .XO#@XOXOXO@OXOXOX$%  ",
"  X X X X X X X  .OO@@OXOXOX@XOXOXO$%  ",
"                 .XO@#X#X#X#@#X#X#X$%  ",
"  @ @ @ @ @ @ @  .OO@@#X#X#X@X#X#X#$%  ",
"                 .XO@@X#X#X#@#X#X#X$%  ",
"          X X    ..O@@#X####@######$%  ",
"        X      X  .O@@######@######$%  ",
"    X X   @ @     .O@@######@#####$$%  ",
"        @    X @  .O@@######@$$$$$$%%  ",
"    @ @           .@@@####@@$%%%%%%%   ",
"           X @    .@@@###@@$%          ",
"                  .@@@##@@$%           ",
"         X @      .@@@#@@$%            ",
"                  .@@@@@$%             ",
"       X @        .O@@@$%              ",
"                  .O@@$%               ",
"       @          .$$$%                ",
"                  .%%%                 ",
"                                       ",
"                                       "};
