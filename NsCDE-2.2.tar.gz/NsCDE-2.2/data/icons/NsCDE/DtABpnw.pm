/* XPM */
/* $XConsortium: DtABpnw.pm /main/3 1995/07/18 16:14:58 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/
static char * DtABpnw_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"28 20 5 1 0 0",
/* colors */
"     s iconGray1     m white c #dededededede",
".    s iconGray4     m white c #949494949494",
"X    s iconGray8     m black c #212121212121",
"o    s iconGray3     m white c #adadadadadad",
"O    s iconGray5     m black c #737373737373",
/* pixels */
"                            ",
" ..........................X",
" .XXXXXXXXXXXXXXXXXXXXXXXX.X",
" .Xooooooooooooooooooooooo.X",
" .Xooooooooooooooooooooooo.X",
" .Xooooooooooooooooooooooo.X",
" .Xooooooooooooooooooooooo.X",
" .Xooooooooooooooooooooooo.X",
" .Xooooooooooooooooo   ooo.X",
" .X                 XXX   .X",
" .XXXXXXXXXXXXXXXXXXXOXXXX.X",
" .XoooooooooooooooooXXXooo.X",
" .Xooooooooooooooooooooooo.X",
" .Xooooooooooooooooooooooo.X",
" .Xooooooooooooooooooooooo.X",
" .Xooooooooooooooooooooooo.X",
" .Xooooooooooooooooooooooo.X",
" .Xooooooooooooooooooooooo.X",
" ..........................X",
" XXXXXXXXXXXXXXXXXXXXXXXXXXX"};
