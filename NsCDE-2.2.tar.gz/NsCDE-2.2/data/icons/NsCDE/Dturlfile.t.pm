/* XPM */
/****************************************************************
*  Copyright (c) 1996 Sun Microsystems, Inc.
*  All Rights Reserved
*****************************************************************/
static char * SDturlfilefolder_t_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"16 16 8 1 0 0",
/* colors */
" 	s none	m none	c none",
".	s iconColor2	m white	c white",
"X	s iconGray6	m black	c #636363636363",
"o	s iconColor5	m black	c blue",
"O	s iconGray8	m black	c #212121212121",
"+	s iconGray5	m black	c #737373737373",
"@	s iconGray2	m white	c #bdbdbdbdbdbd",
"#	s iconColor1	m black	c black",
/* pixels */
"          ....X ",
"         .ooooOX",
"  ............+O",
" .@@@@@@@@@@@@+O",
" .@..........@+O",
" .@.@@@@@@@@#@+O",
" .@.@o@+@++@#@+O",
" .@.@oo@@@@@#@+O",
" ooooooo@+@@#@+O",
"oooo@oo@@@@@#@+O",
"ooo.@o@@++@@#OOX",
"ooo.@@@@@@@@#   ",
" oo.@+@++@+@#   ",
"  o.@@@@@@@@#   ",
"   .@@@@@@@@#   ",
"   .#########   "};
