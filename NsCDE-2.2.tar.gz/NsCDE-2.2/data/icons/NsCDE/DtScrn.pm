/* XPM */
/* $XConsortium: DtScrn.pm /main/3 1995/07/18 16:26:01 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/

static char * Screen [] = {
/* width height ncolors cpp [x_hot y_hot] */
"45 37 11 1 0 0",
/* colors */
" 	s none	m none	c none",
".    s bottomShadowColor m black c #636363636363",
"X	s iconColor2	m white	c white",
"o    s topShadowColor m white c #bdbdbdbdbdbd",
"O    s iconGray1     m white c #dededededede",
"+    s iconGray2     m white c #bdbdbdbdbdbd",
"@    s iconGray7     m black c #424242424242",
"#    s iconGray8     m black c #212121212121",
"$	s iconColor5	m black	c blue",
"%    s iconGray3     m white c #adadadadadad",
"&    s iconGray4     m white c #949494949494",
/* pixels */
"                                             ",
"                                             ",
"  .........................................  ",
"  .XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXo  ",
"  .XO+O+O+O+O++O++O++O+++++++++++++++++++@o  ",
"  .X+O+O+O+O++O++O++O++++++++++++++++++++@o  ",
"  .XO+@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@++@o  ",
"  .X+O@#$#$#$#$#$#$#$#$#$#$#$#$#$#$#$#X++@o  ",
"  .XO+@%%%%%%%%%%%%%%%%%%%%%%%%%%%%%&&X++@o  ",
"  .X+O@$$$XXX$XXX$$$$$$$$$$$$$$$$$$$$$X++@o  ",
"  .XO+@%%+XXX+XXX+++++++++++++++++%%&&X++@o  ",
"  .X+O@$$$X$X$X$X$$$$$$$$$$$$$$$$$$$$$X+%@o  ",
"  .XO+@%+OXXXOXXXOOOOOOOOOOOOOOOO+++%&X++@o  ",
"  .X++@$$$XXX$XXX$$$$$$$$$$$$$$$$$$$$$X%+@o  ",
"  .X+O@%+OXXXOXXXOXOXOXOXOXOXOOOOO+%%&X++@o  ",
"  .XO+@$$$XXX$XXX$$$$$$$$$$$$$$$$$$$$$X+%@o  ",
"  .X++@%+OXXXXXXXXXXXXXXXXXXOXOOO+++%&X++@o  ",
"  .X+O@$$$XXX$XXX$$$$$$$$$$$$$$$$$$$$$X%+@o  ",
"  .XO+@%%+XXXXXXXXXXXXXXXXXXOXOOO+O+%&X+%@o  ",
"  .X++@$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$X++@o  ",
"  .X+O@%%+OXOXOXOXOXOXOXOXOXOXOOO+O+%&X%+@o  ",
"  .X++@$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$X+%@o  ",
"  .XO+@%+++++O+O+O+OOOO+O+O+O+O+O+%+%&X++@o  ",
"  .X++@$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$X%+@o  ",
"  .X++@%%+++++++++++++++++++++++%%%%%&X+%@o  ",
"  .X++@$@$@$@$@$@$@$@$@$@$@$@$@$@$@$@$X%+@o  ",
"  .X++@%%%%%%%%+%+%+%+%+%+%+%+%+%%%%%%X+%@o  ",
"  .X++@@$@$@$@$@$@$@$@$@$@$@$@$@$@$@$@X%+@o  ",
"  .X++@XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX+%@o  ",
"  .X++++++++++++++++%+++%++%++%++%+%+%+%+@o  ",
"  .X++++++++++++++%+++%++%++%++%++%+%+%+%@o  ",
"  .X@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@o  ",
"  .oooooooooooooooooooooooooooooooooooooooo  ",
"                                             ",
"                                             ",
"                                             ",
"                                             "};
