/* XPM */
/* $XConsortium: DtMrfc.l.pm /main/3 1995/07/18 16:23:17 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/

static char * DtMrfc_l_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"48 48 10 1 0 0",
/* colors */
" 	s none	m none	c none",
".    s iconGray2     m white c #bdbdbdbdbdbd",
"X    s iconGray1     m white c #dededededede",
"o	s iconColor5	m black	c blue",
"O    s iconGray3     m white c #adadadadadad",
"+    s iconGray4     m white c #949494949494",
"@    s iconGray5     m black c #737373737373",
"#	s iconColor2	m white	c white",
"$	s iconColor4	m white	c green",
"%    s iconGray6     m black c #636363636363",
/* pixels */
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                                ..........      ",
"                               .XXXXXXXXXX.     ",
"                              .XooooooooooX.    ",
"                             .XooooooooooooX.   ",
"   XXXXXXXXXXXXXXXXXXXXXXXXXXXOOOOOOOOOOOOOOO+  ",
"  X+++++++++++++++++++++++++++++++++++++++++++@ ",
" .XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXO@@ ",
" .X.........................................O@@ ",
" .X.........................................O@@ ",
" .X.........................................O@@ ",
" .X...##################################O...O@@ ",
" .X...#XXXXXXXXXXXXXXXXXXXXXXXXXXXXOXXOXO@..O@@ ",
" .X...#X@@X@@XXXXXXXXXXXXXXXXXXXXXXX$$XXO@..O@@ ",
" .X...#XXXXXXXXXXXXXXXXXXXXXXXXXXXXO$$OXO@..O%@ ",
" .X...#X@X@@@XXXXXXXXXXXXXXXXXXXXXXX$$XXO@..O@@ ",
" .X...#XXXXXXXXXXXXXXXXXXXXXXXXXXXXOXXOXO@..O@@ ",
" .X...#XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXO@..O%@ ",
" .X...#XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXO@..O@@ ",
" .X...#XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXO@..O%@ ",
" .X...#XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXO@..O@@ ",
" .X...#XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXO@..O%@ ",
" .X...#XXXXXXXXXX++X+++X+++X+XXXXXXXXXXXO@..O%@ ",
" .X...#XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXO@..O%@ ",
" .X...#XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXO@..O%@ ",
" .X...#XXXXXXXXXX++++X+++X+++X+XXXXXXXXXO@..O%@ ",
" .X...#XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXO@..O%@ ",
" .X...#XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXO@..O%@ ",
" .X...#OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO@..O%@ ",
" .X....@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@..O%@ ",
" .X.........................................O%@ ",
" .X.........................................O%@ ",
" .X.........................................O%@ ",
" ..O.O.O.O.O.O.O.O.O.O.O.O.O.O.O.O.O.O.O.O.OOO@ ",
"  @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@  ",
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                                                "};
