/* XPM */
/* $XConsortium: Fpterm.s.pm /main/3 1995/07/18 17:05:24 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/

static char * Fterm [] = {
/* width height ncolors cpp [x_hot y_hot] */
"24 24 10 1 0 0",
/* colors */
" 	s none	m none	c none",
".    s bottomShadowColor m black c #636363636363",
"X    s iconGray1     m white c #dededededede",
"o    s topShadowColor m white c #bdbdbdbdbdbd",
"O	s iconColor2	m white	c white",
"+    s iconGray6     m black c #636363636363",
"@    s iconGray8     m black c #212121212121",
"#    s iconGray7     m black c #424242424242",
"$    s iconGray4     m white c #949494949494",
"%    s iconGray5     m black c #737373737373",
/* pixels */
"                        ",
"     ..............     ",
"    .XXXXXXXXXXXXXoo    ",
"   .OOOOOOOOOOOOOOOOo   ",
"   .O++++++++++++++@o   ",
"   .O+@@@@@@@@@@@@O@o   ",
"   .O+@##########@O@o   ",
"   .O+@##########@O@o   ",
"   .O+@$X##$X####@O@o   ",
"   .O+@#$####$###@O@o   ",
"   .O+@##########@O@o   ",
"   .O+@##########@O@o   ",
"   .O+@@@@@@@@@@@@O@o   ",
"   .O+OOOOOOOOOOOOO@o   ",
"    O@@@@@@@@@@@@@@o    ",
"     oo@++++++++@oo     ",
"  .....@@%%%%%%@@o....  ",
" .OO%O%O%O%O%O%O%OO%O%. ",
".OO%O%O%O%O%O%O%OO%O%OOo",
".OOOOOOOOOOOOOOOOOOOOOO@",
" @@@@@@@@@@@@@@@@@@@@@@o",
"  oooooooooooooooooooooo",
"                        ",
"                        "};
