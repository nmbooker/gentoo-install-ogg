/* XPM */
/*********************************************************************
*  (c) Copyright 1999 Sun Microsystems, Inc.
**********************************************************************/
static char * Window_t_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"16 16 7 1 0 0",
/* colors */
" 	s none	m none	c none",
".	s iconGray6	m black	c #636363636363",
"X	s iconGray1	m white	c #dededededede",
"o	s iconGray2	m white	c #bdbdbdbdbdbd",
"O	s iconGray8	m black	c #212121212121",
"+	s iconGray3	m white	c #adadadadadad",
"@	s iconGray5	m black	c #737373737373",
/* pixels */
"                ",
"                ",
"                ",
"                ",
"                ",
"................",
".XXXXXXXXXXXXXXo",
".XXXXXXXXOXXXXXo",
".XX++++++OX++++o",
".XX+XXXX+OX++++o",
".XX+XOOO+OX+++o ",
".XX++++++OX+++o ",
".XX++++++OX+++o ",
".XOOOOOOOOOOOo  ",
".XX+o@@@@@@@@o  ",
".oooooooooooo   "};
