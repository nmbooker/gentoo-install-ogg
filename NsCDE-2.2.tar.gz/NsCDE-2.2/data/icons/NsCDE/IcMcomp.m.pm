/* XPM */
/* $XConsortium: IcMcomp.m.pm /main/3 1995/07/18 17:13:31 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/

static char * IcMcomp_m_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"32 32 11 1 0 0",
/* colors */
" 	s none	m none	c none",
".	s iconColor2	m white	c white",
"X    s iconGray1     m white c #dededededede",
"o    s iconGray6     m black c #636363636363",
"O    s iconGray8     m black c #212121212121",
"+    s iconGray7     m black c #424242424242",
"@    s iconGray4     m white c #949494949494",
"#	s iconColor6	m white	c yellow",
"$    s iconGray3     m white c #adadadadadad",
"%    s iconGray2     m white c #bdbdbdbdbdbd",
"&	s iconColor3	m black	c red",
/* pixels */
"      ...................       ",
"      .XXXXXXXXXXXXXXXXXo       ",
"      .XXXXXXXXXXXXXXXXXo       ",
"      .XooXoXoooXooooXoXo       ",
"      .XXXXXXXXXXXXXXXXXo       ",
"      .XooO++XXXXXXXXXXXo       ",
"      .XXX+@@+XXXXXXXXXXo       ",
"      .XXX+@#X+XXXXXXXXXo       ",
"      .XXX+###X+XXXXXXXXo       ",
"      .XXX$+###X+XXXXXXXo       ",
"      .XXX$$+###X+XXXXXXo       ",
"      .XXXX$$+###X+XXXXXo       ",
"      .XXXX$$$+###X+XXXXo       ",
"     ..XXXXX$$$+###X+XXXoo      ",
"   ..@.XXXXXX$$$+###X+XXo@oo    ",
" ..@@@.XXXXXXX$$$+###X+Xo@@@oo  ",
".ooooo.XXXXXXX$$$$+##.X+o+ooooo ",
".Xoo%%.XXXXXXXX$$$$+...X+o%..Xo ",
".XXXooXXXXXXXXXX$$$$+..&X+XXXXo ",
".XXXXXooXXXXXXXXX$$$@+&&&X+XXXo ",
".XXXXXXXooXXXXXXXX@@..+&&+XXXXo ",
".XXXXXXXXXooXXXXXX..$$$++XXXXXo ",
".XXXXXXXXXXXooXX..X$$$$$XXXXXXo ",
".XXXXXXXXXXXXXooXXXX$$XXXXXXXXo ",
".XXXXXXXXXXXXooXooXXXXXXXXXXXXo ",
".XXXXXXXXXXooXXXXXooXXXXXXXXXXo ",
".XXXXXXXXooXXXXXXXXXooXXXXXXXXo ",
".XXXXXXooXXXXXXXXXXXXXooXXXXXXo ",
".XXXXooXXXXXXXXXXXXXXXXXooXXXXo ",
".XXooXXXXXXXXXXXXXXXXXXXXXooXXo ",
".ooXXXXXXXXXXXXXXXXXXXXXXXXXooo ",
"ooooooooooooooooooooooooooooooo "};
