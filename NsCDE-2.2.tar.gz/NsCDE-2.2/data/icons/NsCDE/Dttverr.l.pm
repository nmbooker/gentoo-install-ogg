/* XPM */
/* $XConsortium: Dttverr.l.pm /main/3 1995/07/18 16:51:06 drk $ */
/*************************************************************************/
/**  (c) Copyright 1993, 1994 Hewlett-Packard Company			**/
/**  (c) Copyright 1993, 1994 International Business Machines Corp.	**/
/**  (c) Copyright 1993, 1994 Sun Microsystems, Inc.			**/
/**  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary	**/
/**      of Novell, Inc.						**/
/*************************************************************************/

static char * tree_error_l_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"18 18 4 1 0 0",
/* colors */
"     s topShadowColor m white c #bdbdbdbdbdbd",
".    s background    m black c #949494949494",
"X    s bottomShadowColor m black c #636363636363",
"o	s foreground	m white	c white",
/* pixels */
"                  ",
" ................X",
" .....oooooo.....X",
" ...oooooooooo...X",
" ..ooo......ooo..X",
" ..oooo......oo..X",
" .oo.ooo......oo.X",
" .oo..ooo.....oo.X",
" .oo...ooo....oo.X",
" .oo....ooo...oo.X",
" .oo.....ooo..oo.X",
" .oo......ooo.oo.X",
" ..oo......oooo..X",
" ..ooo......ooo..X",
" ...oooooooooo...X",
" .....oooooo.....X",
" ................X",
" XXXXXXXXXXXXXXXXX"};
