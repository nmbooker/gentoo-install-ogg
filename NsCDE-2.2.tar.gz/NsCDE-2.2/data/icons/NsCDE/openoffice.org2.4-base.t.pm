/* XPM */
static char *base.t[] = {
/* columns rows colors chars-per-pixel */
"16 16 7 1",
"  c black",
". c #800000",
"X c red",
"o c #808080",
"O c #C0C0C0",
"+ c gray100",
"@ c None",
/* pixels */
"........oooo...o",
".......o+++Oo...",
"X.X.++++    X.X.",
".X.X      +O.X.X",
"X.X.X. ++++ X.X.",
".oo+++++  oX.X.X",
"o++O  + X.X.X.Xo",
".o  .X +++OX.X.@",
".....+O..O+....@",
".X.X.+.X.X+X.Xo@",
".....++++++...@@",
".....+....+...@@",
".....+....+...@@",
".....+O..O+...@@",
"......++++....o@",
"...............@"
};
