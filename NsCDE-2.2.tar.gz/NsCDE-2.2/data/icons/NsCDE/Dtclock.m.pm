/* XPM */
/* $XConsortium: Dtclock.m.pm /main/3 1995/07/18 17:09:45 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/

static char * clock [] = {
/* width height ncolors cpp [x_hot y_hot] */
"32 32 10 1 0 0",
/* colors */
" 	s none	m none	c none",
".    s iconGray1     m white c #dededededede",
"X    s iconGray3     m white c #adadadadadad",
"o    s iconGray8     m black c #212121212121",
"O    s iconGray7     m black c #424242424242",
"+    s bottomShadowColor m black c #636363636363",
"@    s selectColor m white c #737373737373",
"#    s topShadowColor m white c #bdbdbdbdbdbd",
"$	s iconColor2	m white	c white",
"%    s iconGray5     m black c #737373737373",
/* pixels */
"  ............................  ",
" ..X X X X X X X X X X X X X X. ",
"..X Xoooooooooooooooooooooo X XO",
".X Xo+@@@@@@@@@@@@@@@@@@@@+# X O",
". Xo+@@@@@@@@@@@@@@@@@@@@@@+# XO",
".Xo+@@@@@@@@@@@$$@@@@@@@@@@@+# O",
". o@@@@@@@$@@@@$$@@@@$@@@@@@@#XO",
".Xo@@@@@@@@@@@@@@@@@@@@@@@@@@# O",
". o@@@@@@@@@@@@@@@@@@@@@@@@@@#XO",
".Xo@@@@@@@$@@@@@@@@@@@@@@@@@@# O",
". o@@@$@@@O$@@@@@@@@@@@@@$@@@#XO",
".Xo@@@@@@@@O$@@@@@@@@@$@@@@@@# O",
". o@@@@@@@@@O$@@@@@@@$o@@@@@@#XO",
".Xo@@@@@@@@@@O$@@@@@$o@@@@@@@# O",
". o@@@@@@@@@@@O$@@@$o@@@@@@@@#XO",
".Xo@@$$@@@@@@@@OX$$o@@@@@$$@@# O",
". o@@$$@@@@@@@@@$%o@@@@@@$$@@#XO",
".Xo@@@@@@@@@@@@$@O$@@@@@@@@@@# O",
". o@@@@@@@@@@@@o@@O@@@@@@@@@@#XO",
".Xo@@@@@@@@@@@@@@@@@@@@@@@@@@# O",
". o@@@@@@@@@@@@@@@@@@@@@@@@@@#XO",
".Xo@@@$@@@@@@@@@@@@@@@@@@$@@@# O",
". o@@@@@@@@@@@@@@@@@@@@@@@@@@#XO",
".Xo@@@@@@@@@@@@@@@@@@@@@@@@@@# O",
". o@@@@@@@@@@@@@@@@@@@@@@@@@@#XO",
".Xo@@@@@@@$@@@@$$@@@@$@@@@@@@# O",
". o+@@@@@@@@@@@$$@@@@@@@@@@@##XO",
".X #+@@@@@@@@@@@@@@@@@@@@@@##X O",
". X #+@@@@@@@@@@@@@@@@@@@@##X XO",
".X X ######################X X O",
" .X X X X X X X X X X X X X X O ",
"  OOOOOOOOOOOOOOOOOOOOOOOOOOOO  "};
