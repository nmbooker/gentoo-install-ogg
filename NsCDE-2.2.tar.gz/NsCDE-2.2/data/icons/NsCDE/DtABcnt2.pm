/* XPM */
/* $XConsortium: DtABcnt2.pm /main/3 1995/07/18 17:08:40 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/
static char * DtABcnt2_x_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"28 20 9 1 0 0",
/* colors */
"     s iconGray4     m white c #949494949494",
".	s iconColor1	m black	c black",
"X    s iconGray2     m white c #bdbdbdbdbdbd",
"o    s iconGray1     m white c #dededededede",
"O    s iconGray2     m white c #bdbdbdbdbdbd",
"+	s iconColor2	m white	c white",
"@    s iconGray5     m black c #737373737373",
"#    s iconGray8     m black c #212121212121",
"$    s iconGray3     m white c #adadadadadad",
/* pixels */
"                            ",
"                            ",
"  .......X                  ",
"  .ooooooO++                ",
"  .o+ooo@++.  ...           ",
"  .+++o@++.    .            ",
"  +++++++.     . .          ",
"  #+++++.O     . . .......  ",
"  .@+++.@X                  ",
"  .o@+.@@X                  ",
"  XXXOOXXX                  ",
"                            ",
"                            ",
"  ########################  ",
"  #      OOOO#OOO#       O  ",
"  #      O$$$#O$$#       O  ",
"  #      O########       O  ",
"  #OOOOOOOOOOOOOOOOOOOOOOO  ",
"                            ",
"                            "};
