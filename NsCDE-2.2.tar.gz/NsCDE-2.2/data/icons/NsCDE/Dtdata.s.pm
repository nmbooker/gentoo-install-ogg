/* XPM */
/* $XConsortium: Dtdata.s.pm /main/3 1995/07/18 16:33:29 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/

static char * data [] = {
/* width height ncolors cpp [x_hot y_hot] */
"17 22 8 1 0 0",
/* colors */
" 	s none	m none	c none",
".	s iconColor2	m white	c white",
"X    s iconGray8     m black c #212121212121",
"o    s iconGray1     m white c #dededededede",
"O    s iconGray5     m black c #737373737373",
"+    s iconGray2     m white c #bdbdbdbdbdbd",
"@    s iconGray3     m white c #adadadadadad",
"#	s iconColor1	m black	c black",
/* pixels */
"                 ",
"                 ",
"                 ",
"                 ",
"  .............X ",
"  .ooooooooooooX ",
"  .ooooooooooooX ",
"  .oOOOoOoOOOooX ",
"  .ooooooooooooX ",
"  .oO+O@O@OOoooX ",
"  .ooooooooooooX ",
"  .oOO@OO+OooooX ",
"  .ooooooooooooX ",
"  .oOOO@OOOOOooX ",
"  .ooooooooooooX ",
"  .oOOOOOoOOOooX ",
"  .ooooooooooooX ",
"  .ooooooooooooX ",
"  .ooooooooooooX ",
"  XXXXXXX####### ",
"                 ",
"                 "};
