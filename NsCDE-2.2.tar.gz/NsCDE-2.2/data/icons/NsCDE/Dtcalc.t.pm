/* XPM */
/* $XConsortium: Dtcalc.t.pm /main/3 1995/07/18 16:32:51 drk $ */
static char * Dtcalc_t_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"16 16 12 1 0 0",
/* colors */
" 	s none	m none	c none",
".    s iconGray2     m white c #bdbdbdbdbdbd",
"X    s iconGray5     m black c #737373737373",
"o    s iconGray7     m black c #424242424242",
"O    s iconGray6     m black c #636363636363",
"+    s bottomShadowColor m black c #636363636363",
"@    s iconGray3     m white c #adadadadadad",
"#	s iconColor6	m white	c yellow",
"$	s iconColor3	m black	c red",
"%	s iconColor4	m white	c green",
"&    s iconGray8     m black c #212121212121",
"*    s selectColor m white c #737373737373",
/* pixels */
"   ........     ",
"  .XoooooooX    ",
"  .oOOOoOOOX+   ",
"  .X@@@@@@@X+   ",
"  .XXXXXXXXX+   ",
"  .X@o@o@ooX+   ",
"  .XXXXXXXXX+   ",
"  .X.o.o.o#X+   ",
"  .XXXXXXXXX+   ",
"  .X.o.o.o$X+   ",
"  .XXXXXXXXX+   ",
"  .X.o.o.o%X+   ",
"  .XXXXXXXXX+   ",
"  .X.o.o.ooX+   ",
"   XXXXXXXX&+   ",
"    ++++++++*   "};
