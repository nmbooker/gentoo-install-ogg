/* XPM */
/* $XConsortium: Dtcalc.m.pm /main/3 1995/07/18 16:32:44 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/

static char * calc [] = {
/* width height ncolors cpp [x_hot y_hot] */
"32 32 12 1 0 0",
/* colors */
" 	s none	m none	c none",
".    s iconGray3     m white c #adadadadadad",
"X    s iconGray2     m white c #bdbdbdbdbdbd",
"o    s iconGray5     m black c #737373737373",
"O    s iconGray7     m black c #424242424242",
"+    s iconGray8     m black c #212121212121",
"@    s iconGray6     m black c #636363636363",
"#    s bottomShadowColor m black c #636363636363",
"$    s selectColor m white c #737373737373",
"%	s iconColor6	m white	c yellow",
"&	s iconColor3	m black	c red",
"*	s iconColor4	m white	c green",
/* pixels */
"        ................        ",
"       Xooooooooooooooooo       ",
"      .ooOOOOOOOOOOOOOOoo+      ",
"      .oO@o@o@o@o@O@o@o.o+#     ",
"      .oOo@o@O@oOo@o@O@.o+#$    ",
"      .oO@o@o@o@o@O@o@o.o+#$    ",
"      .oo..............oo+#$    ",
"      .oooooooooooooooooo+#$    ",
"      .oooooooooooooooooo+#$    ",
"      .ooo.oo.oo.oo.oo.oo+#$    ",
"      .oo.oO.oO.oO.oO.oOo+#$    ",
"      .oooOooOooOooOoooOo+#$    ",
"      .oooooooooooooooooo+#$    ",
"      .ooXXoXXoXXoo.o%.oo+#$    ",
"      .ooXoOXoOXoO.oO.oOo+#$    ",
"      .oooOOoOOoOOoOooOoo+#$    ",
"      .oooooooooooooooooo+#$    ",
"      .ooXXoXXoXXoo.o&.oo+#$    ",
"      .ooXoOXoOXoO.oO.oOo+#$    ",
"      .oooOOoOOoOOoOooOoo+#$    ",
"      .oooooooooooooooooo+#$    ",
"      .ooXXoXXoXXoo.o*.oo+#$    ",
"      .ooXoOXoOXoO.oO.oOo+#$    ",
"      .oooOOoOOoOOoOooOoo+#$    ",
"      .oooooooooooooooooo+#$    ",
"      .ooXXoXXoXXoo....oo+#$    ",
"      .ooXoOXoOXoO.ooooOo+#$    ",
"      .oooOOoOOoOOoOOOOoo+#$    ",
"       ooooooooooooooooo++#$    ",
"        ++++++++++++++++++#$    ",
"         #################$$    ",
"          $$$$$$$$$$$$$$$$$     "};
