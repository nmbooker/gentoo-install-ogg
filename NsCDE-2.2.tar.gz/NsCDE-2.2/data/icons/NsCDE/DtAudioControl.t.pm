/* XPM */
/*********************************************************************
*  (c) Copyright 1999 Sun Microsystems, Inc.
**********************************************************************/
static char * audiomixer_t_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"16 16 11 1 0 0",
/* colors */
" 	s none	m none	c none",
".	s iconGray6	m black	c #636363636363",
"X	s iconGray8	m black	c #212121212121",
"o	s iconColor2	m white	c white",
"O	s iconGray1	m white	c #dededededede",
"+	s iconGray3	m white	c #adadadadadad",
"@	s iconGray2	m white	c #bdbdbdbdbdbd",
"#	s iconGray7	m black	c #424242424242",
"$	s iconColor5	m black	c blue",
"%	s iconGray4	m white	c #949494949494",
"&	s iconGray5	m black	c #737373737373",
/* pixels */
"      ...  XXXX ",
"      .oo. XOOX ",
"      .o++.XO@X ",
"  #o  .o#o+XXXX ",
" #oO# .O#OX$%$%X",
"+.o. &.O#+X%$%$X",
".o+# .OO#O+XXXX+",
"#o+# ..O#OOX&.#.",
"#o+# .O+#+%X&@X.",
".o+# .%+#&&XO@X.",
"+.o. &.+###XO@X.",
" #oO# .+###XO@X ",
"  #o  #+##XXO@X ",
"      #+#X@XO@X ",
"      XXX@ XXXX ",
"      @@@       "};
